import org.junit.Assert;
import org.junit.jupiter.api.Test;

class PonyExpressTest {

	@Test
	void menosDeCienMillastest() {
		
		PonyExpress pony = new PonyExpress();
		
		Assert.assertEquals(1, pony.jinetes(new int[] {18, 15}));
	}
	
	@Test
	void masDeCienMillastest() {
		
		PonyExpress pony = new PonyExpress();
		
		Assert.assertEquals(2, pony.jinetes(new int[] {43, 23, 40, 13}));
	}
	
	@Test
	void masDeDoscientasMillastest() {
		
		PonyExpress pony = new PonyExpress();
		
		Assert.assertEquals(3, pony.jinetes(new int[] {33, 8, 16, 47, 30, 30, 46}));
	}
	
	@Test
	void tresJinetesEnMenosDeDoscientasMillastest() {
		
		PonyExpress pony = new PonyExpress();
		
		Assert.assertEquals(3, pony.jinetes(new int[] {51, 51, 51}));
	}
	
	@Test
	void cuatroJinetestest() {
		
		PonyExpress pony = new PonyExpress();
		
		Assert.assertEquals(4, pony.jinetes(new int[] {6, 24, 6, 8, 28, 8, 23, 47, 17, 29, 37, 18, 40, 49}));
	}



}
