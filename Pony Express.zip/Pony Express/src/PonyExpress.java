public class PonyExpress {

	public int jinetes(int[] estaciones) {
		int millas = 0, cantJinetes = 1;

		for (int i = 0; i < estaciones.length; i++) {

			millas += estaciones[i];

			if (millas >= 100) {

				cantJinetes++;
				
				millas = 0;
				millas += estaciones[i];
			}

		}
		return cantJinetes;
	}
}
